package coding.challenge;

public class Main {

    public static void main(String[] args) {

        System.out.println("33: " + Scores.count(33));
        System.out.println("18: " + Scores.count(18));
    }

}
