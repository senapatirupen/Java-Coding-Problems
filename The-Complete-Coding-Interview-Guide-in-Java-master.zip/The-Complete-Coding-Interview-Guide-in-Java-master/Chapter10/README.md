# Arrays and strings
This chapter covers 29 popular problems involving strings and arrays. 
