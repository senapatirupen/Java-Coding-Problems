package coding.challenge;

public class Main {

    public static void main(String[] args) {

        String str = "abbb vvvv s rttt rr eeee f";        

        System.out.println("Initial: " + str);                
        System.out.println("Result : " + Strings.shrink(str));                
    }

}
