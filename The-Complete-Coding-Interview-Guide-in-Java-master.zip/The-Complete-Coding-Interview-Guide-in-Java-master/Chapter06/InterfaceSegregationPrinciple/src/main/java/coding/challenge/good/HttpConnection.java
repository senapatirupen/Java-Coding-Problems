package coding.challenge.good;

public interface HttpConnection extends Connection {
    
    public void http();
}
