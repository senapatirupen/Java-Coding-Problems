package coding.challenge.good;

public interface Shape { 
    
    public double area();
}
