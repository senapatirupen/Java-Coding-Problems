package coding.challenge.bad;

public interface Shape {    
}
