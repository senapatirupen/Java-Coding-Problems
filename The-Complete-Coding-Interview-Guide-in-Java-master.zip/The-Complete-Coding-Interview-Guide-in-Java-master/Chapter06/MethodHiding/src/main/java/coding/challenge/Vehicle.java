package coding.challenge;

public class Vehicle {

    public static void move() {
        System.out.println("Moving a vehicle");
    }
}
