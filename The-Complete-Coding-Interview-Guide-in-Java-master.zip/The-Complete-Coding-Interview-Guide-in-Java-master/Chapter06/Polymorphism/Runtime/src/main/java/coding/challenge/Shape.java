package coding.challenge;

public interface Shape {

    public void draw();
}
