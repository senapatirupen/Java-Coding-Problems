package coding.challenge;
 
public class Main {

    public static void main(String[] args) {

       Pair pair = Pair.of("left", "right");
       
       System.out.println(pair.left);
       System.out.println(pair.right);
    }

}
