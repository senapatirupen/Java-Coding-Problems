package coding.challenge;

import coding.challenge.vending.machine.VendingMachine;

public class Main {
 
    public static void main(String[] args) {

        VendingMachine vm = new VendingMachine();        
    }

}
