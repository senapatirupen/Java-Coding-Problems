package coding.challenge;
 
public class Main {

    public static void main(String[] args) {

        int[] numbers = {0, 4, 2, 3, 1, 5, 6, 2, 3, 12, 0, 4, 1};
        
        Bits.printDuplicates(numbers);
    }

}
