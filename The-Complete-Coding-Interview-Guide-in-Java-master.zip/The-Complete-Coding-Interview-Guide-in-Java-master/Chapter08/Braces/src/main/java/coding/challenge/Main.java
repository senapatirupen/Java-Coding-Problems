package coding.challenge;
 
import java.util.List;

public class Main {

    public static void main(String[] args) {
      
       List<String> results = Braces.embrace(3);       
       
       System.out.println("Output: " + results);
    }

}
