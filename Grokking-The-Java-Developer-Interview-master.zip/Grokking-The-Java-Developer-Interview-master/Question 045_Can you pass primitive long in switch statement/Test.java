package com.test;

public class Test {

	public static void main(String[] args) {

		long num = 5;
		
		switch(num) {
		
		}
		
	}

}