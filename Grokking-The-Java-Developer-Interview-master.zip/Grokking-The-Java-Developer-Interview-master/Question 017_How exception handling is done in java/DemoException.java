package com.tech;

import java.io.File;
import java.io.FileReader;

public class DemoException {

	public static void main(String[] args) {

		try {
			FileReader f = new FileReader("C:\\temp\\dummy.txt");
		}
		
	}

}