package com.test;

public class Test {
	public static void main(String[] args) {
		String s1 = "Mark";
		String s2 = "John";
		String s3 = "Mark";
		
		System.out.println("s1.equals(s2): " + s1.equals(s2));
		System.out.println("s1.equals(s3): " + s1.equals(s3));
	}
}