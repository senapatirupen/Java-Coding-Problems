package com.exception;

public class TestException {
	public static void main(String[] args) {
		System.out.println("Program Started");
		int a = 15/0;
		System.out.println("Program End");
	}
}