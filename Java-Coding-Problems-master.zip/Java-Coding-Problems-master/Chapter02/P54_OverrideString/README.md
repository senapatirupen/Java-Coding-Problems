# Overriding toString()
Explain and exemplify practices for overriding **toString()**.
