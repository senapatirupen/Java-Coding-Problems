package modern.challenge;

public class TennisPlayer extends Player{    
}
