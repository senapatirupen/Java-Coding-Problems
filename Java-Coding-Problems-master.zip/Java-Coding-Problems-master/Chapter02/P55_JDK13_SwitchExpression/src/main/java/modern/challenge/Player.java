package modern.challenge;

public class Player {    
}
