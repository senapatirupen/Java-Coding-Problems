package modern.challenge;

public class SnookerPlayer extends Player {   
}
