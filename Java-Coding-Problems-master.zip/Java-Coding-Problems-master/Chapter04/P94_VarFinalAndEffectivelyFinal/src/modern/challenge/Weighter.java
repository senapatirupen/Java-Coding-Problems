package modern.challenge;

public interface Weighter {
    
    float getMarginOfError();
}
