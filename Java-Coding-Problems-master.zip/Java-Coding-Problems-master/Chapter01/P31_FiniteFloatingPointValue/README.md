# Double/float is a finite floating-point value
Write a program that determines if the given **double**/**float** value is a finite floating-point value.