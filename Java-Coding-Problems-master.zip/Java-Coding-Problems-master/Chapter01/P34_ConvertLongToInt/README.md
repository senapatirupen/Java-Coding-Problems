# Convert a long to an int
Write a program that converts a **long** to an **int**.