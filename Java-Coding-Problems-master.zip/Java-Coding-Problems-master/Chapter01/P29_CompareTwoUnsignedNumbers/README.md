# Compare two unsigned numbers
Write a program that compares the given two numbers as unsigned.