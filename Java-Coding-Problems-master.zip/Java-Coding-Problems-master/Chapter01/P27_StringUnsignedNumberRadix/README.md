# String as an unsigned number in the radix
Write a program that parses the given string to an unsigned number (**int** or **long**) in the given radix.