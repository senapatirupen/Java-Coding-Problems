# Apply indentation
Write several snippets of code for applying indentation to the given text.