# Declare multiline strings (text blocks)
Write a program that declares multiline strings or text blocks.
