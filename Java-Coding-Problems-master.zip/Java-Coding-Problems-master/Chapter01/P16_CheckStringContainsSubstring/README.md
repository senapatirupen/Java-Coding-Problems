# Check that string contains a substring
Write a program that checks if the given string contains the given substring.