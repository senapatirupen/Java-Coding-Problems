# Concatenate same string n times
Write a program that concatenates the same string of a given number of times.