# Checking if two arrays are equals or mismatch
Write a program that checks if the two given arrays are equals or there is a mismatch.
