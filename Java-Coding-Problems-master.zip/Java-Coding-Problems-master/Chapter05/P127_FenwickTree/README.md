# Fenwick Tree or Binary Indexed Tree
Write a program that implements the Fenwick Tree algorithm.
