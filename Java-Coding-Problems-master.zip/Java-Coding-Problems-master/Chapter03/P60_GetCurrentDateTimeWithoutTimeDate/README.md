# Get the current date/time without time/date
Write a program that extracts the current date without time and the current time without date.
