# Machine time via Instant class
Explain and exemplify the **Instant** API.
