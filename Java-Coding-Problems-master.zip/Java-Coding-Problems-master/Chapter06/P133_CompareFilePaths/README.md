# Comparing file paths
Write several examples for comparing the given file paths.
