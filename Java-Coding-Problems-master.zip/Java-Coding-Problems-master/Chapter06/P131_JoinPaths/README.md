# Joining file paths
Write several examples for joining (combining) file paths. Define a fix path and append to it different other paths (or replace a part of it with other paths).
