# Current directory
Write a program that return the current project root directory
